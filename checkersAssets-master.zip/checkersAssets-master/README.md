# checkersAssets
This has the pictures needed to complete the checkers project
